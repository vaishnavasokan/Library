<?php
    header('Location:library.html');
?>