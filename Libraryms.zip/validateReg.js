function validateReg()
{

    
}